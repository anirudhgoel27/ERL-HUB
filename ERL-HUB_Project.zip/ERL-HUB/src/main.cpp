#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <memory>
#include <functional>
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <limits>
#include <type_traits>

namespace ReliefOps {
namespace Inventory {

class CargoOverweightException : public std::exception {
public: const char* what() const noexcept override { return "Cargo payload exceeds the vehicle/depot limit."; }
};
class FuelDepletionException : public std::exception {
public: const char* what() const noexcept override { return "Vehicle fuel level is insufficient for the planned route."; }
};
class DamagedCorridorException : public std::exception {
public: const char* what() const noexcept override { return "The selected corridor is reported damaged or blocked."; }
};

class ReliefCargo {
    int id_;
    std::string name_;
    double weightKg_;
    int quantity_;
public:
    ReliefCargo(int id=0, const std::string& name="Unnamed", double weight=0.0, int qty=0)
        : id_(id), name_(name), weightKg_(weight), quantity_(qty) {
        if (weight < 0 || qty < 0) throw std::invalid_argument("Cargo weight and quantity must be non-negative.");
    }
    int id() const { return id_; }
    const std::string& name() const { return name_; }
    double weightKg() const { return weightKg_; }
    int quantity() const { return quantity_; }
    double totalWeight() const { return weightKg_ * quantity_; }
    ReliefCargo& operator+=(int qty) { if (qty < 0) throw std::invalid_argument("Cannot restock negative quantity."); quantity_ += qty; return *this; }
    ReliefCargo& operator-=(int qty) { if (qty < 0 || qty > quantity_) throw std::out_of_range("Invalid cargo deduction."); quantity_ -= qty; return *this; }
    bool operator==(const ReliefCargo& rhs) const { return id_ == rhs.id_ && name_ == rhs.name_; }
    friend std::ostream& operator<<(std::ostream& os, const ReliefCargo& c) {
        return os << c.id_ << '|' << c.name_ << '|' << c.weightKg_ << '|' << c.quantity_;
    }
    friend std::istream& operator>>(std::istream& is, ReliefCargo& c) {
        int id, qty; std::string name; double weight; char delimiter;
        if (is >> id >> delimiter && delimiter=='|' && std::getline(is, name, '|') && is >> weight >> delimiter && delimiter=='|' && is >> qty) {
            c = ReliefCargo(id, name, weight, qty);
        } else is.setstate(std::ios::failbit);
        return is;
    }
};

class DistributionDepot {
    std::string name_;
    double capacityKg_;
    std::vector<ReliefCargo> stock_;
    static int depotCount_;
public:
    DistributionDepot(const std::string& name, double capacity) : name_(name), capacityKg_(capacity) { ++depotCount_; }
    DistributionDepot(const DistributionDepot& other) : name_(other.name_), capacityKg_(other.capacityKg_), stock_(other.stock_) { ++depotCount_; }
    ~DistributionDepot() { --depotCount_; }
    const std::string& name() const { return name_; }
    static int depotCount() { return depotCount_; }
    double stockWeight() const {
        double sum=0; std::for_each(stock_.begin(), stock_.end(), [&sum](const ReliefCargo& c){sum += c.totalWeight();}); return sum;
    }
    DistributionDepot& operator+=(const ReliefCargo& cargo) {
        if (stockWeight() + cargo.totalWeight() > capacityKg_) throw CargoOverweightException();
        auto it=std::find_if(stock_.begin(),stock_.end(),[&cargo](const ReliefCargo& c){return c==cargo;});
        if (it==stock_.end()) stock_.push_back(cargo); else *it += cargo.quantity();
        return *this;
    }
    DistributionDepot& operator-=(const ReliefCargo& cargo) {
        auto it=std::find_if(stock_.begin(),stock_.end(),[&cargo](const ReliefCargo& c){return c==cargo;});
        if(it==stock_.end() || it->quantity()<cargo.quantity()) throw std::out_of_range("Depot does not have requested cargo quantity.");
        *it -= cargo.quantity(); return *this;
    }
    const std::vector<ReliefCargo>& stock() const { return stock_; }
    friend std::ostream& operator<<(std::ostream& os, const DistributionDepot& d) {
        os << "Depot: " << d.name_ << " | Capacity: " << d.capacityKg_ << " kg | Stock: " << d.stockWeight() << " kg\n";
        for(const auto& c:d.stock()) os << "  " << c.id() << " " << c.name() << " | qty=" << c.quantity() << " | " << c.totalWeight() << " kg\n";
        return os;
    }
};
int DistributionDepot::depotCount_ = 0;

// Explicit dynamic manifest: parameterized constructor, deep copy constructor and destructor.
class TransportManifest {
    ReliefCargo* items_;
    std::size_t count_;
public:
    explicit TransportManifest(std::size_t count) : items_(count ? new ReliefCargo[count] : nullptr), count_(count) {}
    TransportManifest(const TransportManifest& other) : items_(other.count_ ? new ReliefCargo[other.count_] : nullptr), count_(other.count_) {
        for(std::size_t i=0;i<count_;++i) items_[i]=other.items_[i];
    }
    TransportManifest& operator=(const TransportManifest& other) {
        if(this!=&other){ ReliefCargo* fresh=other.count_ ? new ReliefCargo[other.count_] : nullptr;
            for(std::size_t i=0;i<other.count_;++i) fresh[i]=other.items_[i];
            delete[] items_; items_=fresh; count_=other.count_; }
        return *this;
    }
    ~TransportManifest(){ delete[] items_; }
    std::size_t size() const{return count_;}
    ReliefCargo& operator[](std::size_t i){if(i>=count_) throw std::out_of_range("Manifest index out of range.");return items_[i];}
    const ReliefCargo& operator[](std::size_t i) const{if(i>=count_) throw std::out_of_range("Manifest index out of range.");return items_[i];}
    friend std::ostream& operator<<(std::ostream& os,const TransportManifest& m){os<<"Manifest items="<<m.count_<<"\n";for(std::size_t i=0;i<m.count_;++i)os<<m.items_[i]<<"\n";return os;}
};

} // Inventory

namespace Logistics {

inline double calculateDistanceKm(double x1, double y1, double x2, double y2) {
    return std::sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
}
inline double calculatePayloadKg(const std::vector<Inventory::ReliefCargo>& cargo) {
    double total=0; std::for_each(cargo.begin(),cargo.end(),[&total](const Inventory::ReliefCargo& c){total+=c.totalWeight();}); return total;
}

// Supply-allocation overloads: general payload allocation and priority triage allocation.
inline void allocateSupply(Inventory::DistributionDepot& depot, const Inventory::ReliefCargo& cargo) { depot += cargo; }
inline void allocateSupply(Inventory::DistributionDepot& depot, const Inventory::ReliefCargo& cargo, int triagePriority) {
    if(triagePriority <= 2) depot += cargo; // urgent triage stock is accepted into the depot
    else throw std::invalid_argument("Medical triage allocation requires priority 1 or 2.");
}

class IncidentCommander {
public:
    template<class Vehicle> static void criticalTriageOverride(Vehicle& v, int priority) { v.priority_ = priority; }
};

class GPSBeacon {
    double x_, y_;
public: GPSBeacon(double x=0,double y=0):x_(x),y_(y){} double x() const{return x_;} double y() const{return y_;}
};
class EmergencyLifeSupportUnit {
    bool operational_;
public: explicit EmergencyLifeSupportUnit(bool on=true):operational_(on){} bool operational() const{return operational_;}
};

class ReliefVehicle {
protected:
    int id_; std::string name_; double payloadLimitKg_; double fuel_; int priority_;
    GPSBeacon gps_; EmergencyLifeSupportUnit lifeSupport_;
    static int operationalVehicles_; static double dispatchedTonnage_;
public:
    ReliefVehicle(int id,const std::string& name,double payload,double fuel,int priority=3)
      :id_(id),name_(name),payloadLimitKg_(payload),fuel_(fuel),priority_(priority),gps_(),lifeSupport_(){++operationalVehicles_;}
    ReliefVehicle(const ReliefVehicle& r):id_(r.id_),name_(r.name_),payloadLimitKg_(r.payloadLimitKg_),fuel_(r.fuel_),priority_(r.priority_),gps_(r.gps_),lifeSupport_(r.lifeSupport_){++operationalVehicles_;}
    virtual ~ReliefVehicle(){--operationalVehicles_;}
    virtual std::string vehicleType() const=0;
    virtual double routeFactor() const=0;
    virtual bool corridorSupported(const std::string& corridor) const=0;
    virtual double evaluateRoute(double distanceKm,const std::string& corridor) const {
        if(!corridorSupported(corridor)) throw Inventory::DamagedCorridorException();
        return distanceKm*routeFactor();
    }
    void dispatch(double distanceKm,const std::string& corridor,double payloadKg) {
        if(payloadKg>payloadLimitKg_) throw Inventory::CargoOverweightException();
        double fuelNeeded=evaluateRoute(distanceKm,corridor);
        if(fuel_<fuelNeeded) throw Inventory::FuelDepletionException();
        fuel_-=fuelNeeded; dispatchedTonnage_ += payloadKg/1000.0;
        std::cout << "Dispatch accepted: " << name_ << " | " << vehicleType() << " | fuel used=" << fuelNeeded << "\n";
    }
    int id() const{return id_;} const std::string& name() const{return name_;} int priority() const{return priority_;}
    double payloadLimit() const{return payloadLimitKg_;}
    static int operationalCount(){return operationalVehicles_;}
    static double dispatchedTonnage(){return dispatchedTonnage_;}
    friend class IncidentCommander;
    friend std::ostream& operator<<(std::ostream& os,const ReliefVehicle& v){return os<<v.id_<<'|'<<v.name_<<'|'<<v.vehicleType()<<'|'<<v.priority_;}
};
int ReliefVehicle::operationalVehicles_=0;
double ReliefVehicle::dispatchedTonnage_=0.0;

class AerialTransport : virtual public ReliefVehicle {
public: AerialTransport(int id,const std::string& n,double p,double f,int pri=2):ReliefVehicle(id,n,p,f,pri){}
 std::string vehicleType() const override{return "AerialTransport";} double routeFactor() const override{return 0.7;}
 bool corridorSupported(const std::string& c) const override{return c=="air" || c=="clear";}
};
class GroundConvoy : virtual public ReliefVehicle {
public: GroundConvoy(int id,const std::string& n,double p,double f,int pri=3):ReliefVehicle(id,n,p,f,pri){}
 std::string vehicleType() const override{return "GroundConvoy";} double routeFactor() const override{return 1.0;}
 bool corridorSupported(const std::string& c) const override{return c=="road" || c=="clear";}
};
class AmphibiousCraft : virtual public ReliefVehicle {
public: AmphibiousCraft(int id,const std::string& n,double p,double f,int pri=3):ReliefVehicle(id,n,p,f,pri){}
 std::string vehicleType() const override{return "AmphibiousCraft";} double routeFactor() const override{return 1.2;}
 bool corridorSupported(const std::string& c) const override{return c=="water" || c=="clear";}
};
class AmphibiousMedicalUnit : public GroundConvoy, public AmphibiousCraft {
public:
    AmphibiousMedicalUnit(int id,const std::string& n,double p,double f,int pri=1)
      :ReliefVehicle(id,n,p,f,pri),GroundConvoy(id,n,p,f,pri),AmphibiousCraft(id,n,p,f,pri){}
    std::string vehicleType() const override{return "AmphibiousMedicalUnit";}
    double routeFactor() const override{return 1.1;}
    bool corridorSupported(const std::string& c) const override{return c=="road" || c=="water" || c=="clear";}
};

template<class T> class PriorityDispatchQueue {
    std::vector<T> items_;
public:
    void push(const T& item){items_.push_back(item);}
    bool empty() const{return items_.empty();}
    std::size_t size() const{return items_.size();}
    void sortByPriority(){std::sort(items_.begin(),items_.end(),[](const T& a,const T& b){if constexpr(std::is_pointer<T>::value) return a->priority()<b->priority(); else return a.priority()<b.priority();});}
    const std::vector<T>& items() const{return items_;}
};
struct UrgentNeedFunctor {
    bool operator()(const Inventory::ReliefCargo& a,const Inventory::ReliefCargo& b) const {return a.id()<b.id();}
};
struct ManifestTable { };
std::ostream& operator<<(std::ostream& os, ManifestTable){os<<std::left<<std::setw(8)<<"ID"<<std::setw(28)<<"VEHICLE"<<std::setw(14)<<"TYPE"<<"PRIORITY\n";return os;}

} // Logistics
} // ReliefOps

// Binary incident record with a rollback guard: records are appended only if all writes succeed.
struct IncidentRecord { int vehicleId; double distanceKm; double payloadKg; int priority; };
void saveIncidentTransactional(const IncidentRecord& record,const std::string& path) {
    { std::ofstream create(path,std::ios::binary|std::ios::app); if(!create) throw std::runtime_error("Cannot create incident log."); }
    std::fstream file(path,std::ios::binary|std::ios::in|std::ios::out);
    if(!file) throw std::runtime_error("Cannot open incident log for update.");
    file.seekg(0,std::ios::end); std::streampos oldEnd=file.tellg();
    file.seekp(oldEnd);
    file.write(reinterpret_cast<const char*>(&record),sizeof(record));
    if(!file){ file.clear(); file.seekp(oldEnd); file.flush(); file.close(); std::filesystem::resize_file(path, static_cast<std::uintmax_t>(oldEnd)); throw std::runtime_error("Write failed; transactional rollback executed."); }
    file.flush(); if(!file){ file.clear(); file.close(); std::filesystem::resize_file(path, static_cast<std::uintmax_t>(oldEnd)); throw std::runtime_error("Flush failed; transactional rollback executed."); }
}
std::vector<IncidentRecord> loadIncidents(const std::string& path) {
    std::vector<IncidentRecord> records; std::fstream file(path,std::ios::binary|std::ios::in);
    if(!file) return records;
    file.seekg(0,std::ios::beg);
    IncidentRecord r; while(file.read(reinterpret_cast<char*>(&r),sizeof(r))) records.push_back(r); return records;
}

int main() {
    using namespace ReliefOps;
    using namespace ReliefOps::Inventory;
    using namespace ReliefOps::Logistics;
    try {
        std::cout << "=== ERL-HUB: Emergency Relief Logistics Hub ===\n";
        DistributionDepot depot("MAIT Regional Depot",50000.0);
        ReliefCargo ration(101,"Ration Kits",2.0,1000), medicine(202,"Trauma Medicine",0.5,300), water(303,"Water Tank",20.0,100);
        allocateSupply(depot,ration); allocateSupply(depot,medicine,1); allocateSupply(depot,water);
        Inventory::TransportManifest manifest(2);
        manifest[0]=ration; manifest[1]=medicine;
        Inventory::TransportManifest copiedManifest(manifest); // deep copy demonstration
        std::cout << copiedManifest << "\n";
        std::cout << depot << "\n";

        std::vector<std::unique_ptr<ReliefVehicle>> fleet;
        fleet.emplace_back(new GroundConvoy(1,"NDRF Truck",5000,180,"road"==std::string("road")?3:3));
        fleet.emplace_back(new AerialTransport(2,"Medical Helicopter",1200,120,1));
        fleet.emplace_back(new AmphibiousCraft(3,"Rescue Boat",2500,100,2));
        fleet.emplace_back(new AmphibiousMedicalUnit(4,"Hybrid Medical Unit",1800,160,1));
        IncidentCommander::criticalTriageOverride(*fleet[0],1);

        PriorityDispatchQueue<ReliefVehicle*> queue;
        for(auto& vehicle:fleet) queue.push(vehicle.get());
        queue.sortByPriority();
        std::cout << ManifestTable{};
        for(auto* v:queue.items()) std::cout << std::left<<std::setw(8)<<v->id()<<std::setw(28)<<v->name()<<std::setw(14)<<v->vehicleType()<<v->priority()<<"\n";

        std::map<std::string,int> inventorySummary;
        std::unordered_map<int,std::string> vehicleDirectory;
        for(const auto& vehicle:fleet) vehicleDirectory[vehicle->id()]=vehicle->name();
        std::cout << "Fleet directory entries (unordered_map): " << vehicleDirectory.size() << "\n";
        std::vector<ReliefCargo> urgentCargo=depot.stock();
        std::sort(urgentCargo.begin(),urgentCargo.end(),UrgentNeedFunctor{});
        std::cout << "Cargo ordered by custom urgent-need functor: ";
        for(const auto& item:urgentCargo) std::cout << item.id() << " ";
        std::cout << "\n";
        for(const auto& c:depot.stock()) inventorySummary[c.name()]=c.quantity();
        std::cout << "\nInventory map summary:\n";
        std::for_each(inventorySummary.begin(),inventorySummary.end(),[](const std::pair<const std::string,int>& p){std::cout<<"  "<<p.first<<": "<<p.second<<" units\n";});

        const double distance=calculateDistanceKm(0,0,30,40); // 50 km
        std::cout << "\nRoute distance utility: " << distance << " km\n";
        fleet[0]->dispatch(distance,"road",2000.0);
        fleet[1]->dispatch(distance,"air",500.0);
        fleet[2]->dispatch(distance,"water",1000.0);
        fleet[3]->dispatch(distance,"road",700.0);

        saveIncidentTransactional({1,distance,2000.0,fleet[0]->priority()},"incident_log.bin");
        const auto history=loadIncidents("incident_log.bin");
        std::cout << "\nPersisted incident records: " << history.size() << "\n";
        std::cout << "Active vehicles: " << ReliefVehicle::operationalCount() << " | Total dispatched: " << ReliefVehicle::dispatchedTonnage() << " metric tonnes\n";

        try { fleet[0]->dispatch(20,"blocked",100.0); }
        catch(const DamagedCorridorException& e){std::cout<<"Handled route exception: "<<e.what()<<"\n";}
        try { fleet[0]->dispatch(1000,"road",6000.0); }
        catch(const CargoOverweightException& e){std::cout<<"Handled payload exception: "<<e.what()<<"\n";}
    } catch(const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n"; return 1;
    }
    return 0;
}
