# ERL-HUB Viva Preparation

## Project in 30 seconds
ERL-HUB is a C++ console simulation for post-earthquake relief logistics. It manages supplies at a depot, represents trucks/helicopters/boats/hybrid medical units through an abstract vehicle class, sorts dispatches by priority, checks payload/fuel/corridor suitability, handles exceptions, and stores incident records in a binary file. It demonstrates OOP concepts from all four CIC-211 units.

## Core concepts to be able to explain

- **Class / object:** `ReliefCargo` defines cargo data and operations; an instance such as `ration` is an object.
- **Encapsulation:** class data members are private/protected and accessed through controlled member functions.
- **Abstraction:** callers dispatch a `ReliefVehicle` through a common interface without needing its route factor details.
- **Inheritance:** specialized vehicle types derive from `ReliefVehicle`.
- **Polymorphism:** virtual `evaluateRoute`, `vehicleType`, `routeFactor`, and `corridorSupported` resolve based on the actual derived type.
- **Virtual inheritance:** shared virtual base avoids two separate `ReliefVehicle` subobjects in the hybrid class diamond.
- **Containership/composition:** a `ReliefVehicle` owns `GPSBeacon` and `EmergencyLifeSupportUnit` member objects.
- **Friend class:** `IncidentCommander` has special access to the protected priority data to demonstrate a critical override.
- **Static member:** `operationalVehicles_` and `dispatchedTonnage_` are shared across every vehicle instance.
- **Operator overloading:** `+=` restocks, `-=` deducts, `==` compares cargo identity, `<<` prints/serializes.
- **Deep copy:** `TransportManifest` allocates a new array and copies items; copied object owns its own array.
- **Template:** `PriorityDispatchQueue<T>` can store a type `T` and sort it using priority interface.
- **Exception:** custom exceptions communicate payload/fuel/corridor failures; catch blocks handle them.
- **Binary streams:** `fstream` writes fixed-layout `IncidentRecord` bytes; `seekg`/`seekp` position stream pointers.
- **STL:** vector stores fleet/cargo/queue, map summarizes inventory, algorithms sort and iterate.

## Common viva questions with short answers

1. **Why is `ReliefVehicle` abstract?** It defines a common vehicle interface but cannot represent a specific vehicle by itself; it has pure virtual `vehicleType`, `routeFactor`, and corridor behavior.
2. **What is runtime polymorphism?** A call through a base pointer invokes the derived override selected at runtime.
3. **Why virtual inheritance?** The hybrid vehicle inherits two branches that share a base; virtual inheritance makes that common base single.
4. **Why a virtual destructor?** Deleting a derived object through a base pointer must run the derived destructor correctly.
5. **What is composition here?** The vehicle contains its GPS beacon and life-support unit as member objects.
6. **What does a friend class do?** It grants declared special access to private/protected members; it should be used sparingly.
7. **What is a static data member?** One shared value for the class, not one per object.
8. **Difference between shallow and deep copy?** Shallow copies an address; deep copy allocates separate owned storage and copies contents.
9. **Why overload `+=`?** It makes a domain operation (restocking) readable and updates the object itself.
10. **What does `what()` return?** A null-terminated diagnostic string describing the exception.
11. **What is a template?** A type-parameterized class/function that can be instantiated for different types.
12. **Why use `std::vector`?** Dynamic-size contiguous collection with automatic memory management.
13. **What does `std::sort` require?** Random-access iterators and a comparison ordering.
14. **What is binary file I/O?** Reading/writing bytes without text formatting conversion.
15. **What is rollback?** Reverting a partial operation to its previous state after a failure.

## Suggested presentation flow
1. Explain the disaster-relief use case and entities.
2. Show cargo/depot restock and inventory summary.
3. Introduce abstract base and fleet hierarchy.
4. Explain virtual inheritance and composition using the hybrid vehicle.
5. Show priority sorting and dispatch success.
6. Trigger a blocked corridor and overweight exception.
7. Show the binary incident file save/readback.
8. Walk through syllabus checklist and mention simulation limitations honestly.
