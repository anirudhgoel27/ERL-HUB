# CIC-211 Syllabus Requirement Mapping — Option 2

This checklist maps the Option 2 requirements in the MAIT project assignment to the implementation in `src/main.cpp`.

## Unit I — Core foundations and call semantics

| Assignment requirement | Demonstration in source |
|---|---|
| `ReliefOps::Logistics` and `ReliefOps::Inventory` namespaces | Namespace blocks in the source |
| Function overloading for supply allocation based on volume/medical triage | `allocateSupply(depot, cargo)` and overload `allocateSupply(depot, cargo, triagePriority)` |
| Call by reference / return by reference to update stock/mission parameters | `ReliefCargo& operator+=`, `ReliefCargo& operator-=`, `DistributionDepot& operator+=/-=` return references; manifest indexed access returns references |
| Inline utilities for distance/payload | `calculateDistanceKm`, `calculatePayloadKg` |
| Friend class `IncidentCommander` | `friend class IncidentCommander` in `ReliefVehicle`; commander updates priority |

## Unit II — Encapsulation, dynamic memory, operator overloading

| Assignment requirement | Demonstration in source |
|---|---|
| `ReliefCargo`, `DistributionDepot`, `TransportVehicle` abstraction | `ReliefCargo`, `DistributionDepot`, abstract `ReliefVehicle` (vehicle abstraction) |
| Static variables/functions for total tonnage and operational vehicles | `ReliefVehicle::operationalVehicles_`, `dispatchedTonnage_`, static accessors; depot count too |
| Dynamic allocation, parameterized/dynamic constructor, deep copy constructor and destructor | `TransportManifest` owns dynamic `ReliefCargo[]`, parameterized constructor, deep-copy constructor, assignment operator, destructor |
| `+=` restock | `DistributionDepot::operator+=` and `ReliefCargo::operator+=` |
| `-=` deduct cargo | `DistributionDepot::operator-=` and `ReliefCargo::operator-=` |
| `==` manifest/cargo identity | `ReliefCargo::operator==` checks ID and name |
| `<<` and `>>` standard I/O/serialization | `ReliefCargo` stream operators; vehicle `<<`; depot and manifest `<<` |

## Unit III — Inheritance, containership, polymorphism

| Assignment requirement | Demonstration in source |
|---|---|
| Base `ReliefVehicle` derived into aerial, ground, amphibious | `AerialTransport`, `GroundConvoy`, `AmphibiousCraft` |
| Hybrid virtual inheritance diamond | branches virtually inherit `ReliefVehicle`; `AmphibiousMedicalUnit` inherits ground + amphibious |
| Compose `GPSBeacon` and `EmergencyLifeSupportUnit` | member objects inside `ReliefVehicle` (composition) |
| Runtime route evaluation via base pointers; virtual destructor | fleet is `vector<unique_ptr<ReliefVehicle>>`; virtual route method and virtual destructor |

## Unit IV — Streams, persistence, exception safety, STL

| Assignment requirement | Demonstration in source |
|---|---|
| Custom exceptions derived from `std::exception` | `CargoOverweightException`, `FuelDepletionException`, `DamagedCorridorException`, each overrides `what()` |
| Binary `fstream` logs; atomic update / rollback; `seekp` and `seekg` | `saveIncidentTransactional` and `loadIncidents`; restore original file size on write/flush failure |
| `vector`, `unordered_map` | `vector` used for cargo/fleet/queue; `unordered_map<int,string>` stores vehicle directory; `map` summarizes inventory. |
| `std::sort`, `std::for_each` | Queue sorting and stock weight/map summaries |
| Generic `PriorityDispatchQueue<T>` | Template class |
| Custom functor sorting urgent medical needs | `UrgentNeedFunctor` is passed to `std::sort` on the depot cargo list |
| User-defined I/O manipulator for tabular manifest printing | `ManifestTable` custom insertion manipulator |

## Coverage note

All major bullet mechanisms for Option 2 are represented in the current source. The named supply-allocation overloads, unordered vehicle directory, and custom functor sorting are implemented and called in the demonstration. Review the exact assignment phrasing and be prepared to explain each mechanism during viva.
