# ERL-HUB Project Report

## 1. Title
Post-Earthquake Multi-Agency Emergency Relief Logistics Hub (ERL-HUB)

## 2. Abstract
After a major earthquake, relief agencies coordinate transport vehicles and critical supplies from regional distribution depots. ERL-HUB is a console-based C++ application prototype that models cargo stock, depots, a heterogeneous relief fleet, route suitability, payload and fuel checks, priority dispatch, and incident persistence. The implementation uses object-oriented programming, STL structures and algorithms, custom exceptions, binary file streams, and virtual inheritance to represent the domain and demonstrate the CIC-211 syllabus.

## 3. Problem statement
Relief dispatch coordination must keep inventory quantities visible, prevent dispatches beyond payload/fuel limits, and prioritize urgent missions. A simple centralized software model can demonstrate how data abstraction and polymorphic vehicle behavior can support this process.

## 4. Objectives
1. Encapsulate relief cargo and depot inventory.
2. Model ground, aerial, amphibious, and hybrid vehicles with common interfaces.
3. Demonstrate function/operator overloading, static metrics, dynamic allocation and deep copying.
4. Use runtime polymorphism for route evaluation.
5. Validate dispatch with custom exceptions.
6. Persist incident records using binary file streams.
7. Use STL containers, algorithms, a generic priority queue, functor and custom output manipulator.

## 5. Scope and assumptions
This is an academic offline simulation. Route names (`road`, `air`, `water`, `clear`) stand in for corridor status. Fuel use is computed with a simplified route-factor model. GPS coordinates are represented by a small composition object. No live GPS, maps, databases, network dispatch, or actual emergency infrastructure is connected.

## 6. Design / modules
- **Inventory module (`ReliefOps::Inventory`)**: `ReliefCargo`, `DistributionDepot`, custom exception types and dynamically allocated `TransportManifest`.
- **Logistics module (`ReliefOps::Logistics`)**: utility calculations, `ReliefVehicle` abstract base, specialized vehicle types, GPS beacon, life-support unit, priority queue, commander access, functor and tabular manipulator.
- **Persistence module (free functions)**: binary incident record append and read-back.
- **Driver (`main`)**: creates demo data, populates depot/fleet, sorts dispatch queue, demonstrates successful and rejected dispatches, and reads persisted records.

### Class relationship overview
```text
ReliefVehicle (abstract; owns GPSBeacon + EmergencyLifeSupportUnit)
├── AerialTransport (virtual ReliefVehicle)
├── GroundConvoy (virtual ReliefVehicle)
├── AmphibiousCraft (virtual ReliefVehicle)
└── AmphibiousMedicalUnit
    ├── GroundConvoy
    └── AmphibiousCraft
       (virtual base prevents duplicate ReliefVehicle)

DistributionDepot ── contains vector<ReliefCargo>
TransportManifest ── owns dynamic ReliefCargo[] (deep-copy semantics)
PriorityDispatchQueue<T> ── generic template container wrapper
```

## 7. Dispatch workflow
1. Create cargo types and stock the depot.
2. Create the mixed fleet using base-class smart pointers.
3. Set priority for a critical vehicle using `IncidentCommander` friend access.
4. Insert base pointers into `PriorityDispatchQueue` and sort by urgency (lower priority number means more urgent).
5. Calculate route distance and dispatch. The vehicle checks corridor compatibility, payload cap and available fuel.
6. On success, deduct modeled fuel and increment dispatched tonnage.
7. Append a compact incident record to binary storage; read the log back for demonstration.
8. Catch and report rejected route/payload examples.

## 8. Exception handling
`CargoOverweightException`, `FuelDepletionException`, and `DamagedCorridorException` derive from `std::exception` and provide `what()` messages. Invalid cargo quantities and manifest indexing also use standard exceptions. The main driver catches exceptions so the demonstration reports failures rather than crashing.

## 9. Persistence
Incident records are written in binary form through `std::fstream`. The append process records the original end offset using `seekg`, writes using `seekp`, and uses file-size restoration as rollback if writing or flushing fails. Readback uses `seekg` and reads fixed-size records. Binary structs are suitable for this local same-build demo; a production application would need versioned, portable serialization.

## 10. Sample test cases
| Test | Input / action | Expected result |
|---|---|---|
| T1 | Add ration, medicine and water to depot | Stock summary displays cargo and weights |
| T2 | Copy a dynamic manifest | Copied manifest contains equivalent records; ownership is independent |
| T3 | Dispatch truck on `road` | Accepted if payload/fuel fit |
| T4 | Dispatch helicopter on `air` | Accepted with aerial route factor |
| T5 | Dispatch boat on `water` | Accepted with amphibious route factor |
| T6 | Dispatch on `blocked` corridor | `DamagedCorridorException` is caught |
| T7 | Payload exceeds truck limit | `CargoOverweightException` is caught |
| T8 | Save then load incident file | Saved record count increases and is read back |
| T9 | Sort fleet priorities | Vehicles appear in ascending priority number (urgent first) |

## 11. Limitations and future enhancements
- Use a database and serialized schema/versioning for long-lived records.
- Add a GUI and authenticated agency roles.
- Integrate actual road damage, fuel station, and location data sources.
- Add more comprehensive automated unit tests and safe transaction handling for inventory + dispatch as one transaction.
- Use a domain-specific route planner rather than route factors.

## 12. Conclusion
ERL-HUB demonstrates an object-oriented relief logistics model that maps the assignment’s required mechanisms to a cohesive scenario. The source and syllabus checklist are included with this report; compile and run the program to observe the behaviors.
